<div>
    {{-- To attain knowledge, add things every day; To attain wisdom, subtract things every day. --}}
    <div class="container red topBotomBordersOut">
        <a>HOME</a>
        <a>ARTICLES</a>
        <a>PORTFOLIO</a>
        <a>ABOUT</a>
        <a>CONTACT</a>
    </div>
</div>
