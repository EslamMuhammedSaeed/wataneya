<?php

/*
|--------------------------------------------------------------------------
| Authentication Language Lines
|--------------------------------------------------------------------------
|
| The following language lines are used during authentication for various
| messages that we need to display to the user. You are free to modify
| these language lines according to your application's requirements.
|
*/

return [
    'dashboard'   => 'الرئيسية',
    'logout' => 'تسجيل الخروج',
    'users' => 'المستخدمين',
    'First name' => 'الاسم الأول',
    'Last name' => 'الاسم الثانى',
    'email' => 'البريد الإلكترونى',
    'action' => 'أكشن',
    'id' => 'الرقم التعريفى',
    'not found' => 'لا يوجد',
    'create' => 'إنشاء',
    'edit' => 'تعديل',
    'update' => 'تعديل',
    'delete' => 'مسح',
    'read' => 'عرض',
    'Submit' => 'تسجيل',
    'Wataneya' => 'وطنية',
    'edit successful' => 'تم التعديل بنجاح', 
    'create successful' => 'تم الإنشاء بنجاح', 
    'add' => 'إضافة',
    'add new' => 'إضافة جديد',
    'name'                 => 'الاسم',
    
];