<?php return array (
  'navbar' => 'App\\Http\\Livewire\\Navbar',
);