

<aside class="main-sidebar sidebar-dark-success elevation-4" style="background-color: #71b7c0 !important">
    <!-- Brand Logo -->
    

    <!-- Sidebar -->
    <div class="sidebar px-0" >
      <!-- Sidebar user panel (optional) -->
      

      <!-- SidebarSearch Form -->
      

      <!-- Sidebar Menu -->
      <nav class="mt-4 px-0">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
            <li class="nav-item mb-2">
                <a href="#" class="nav-link mx-auto">
                    <i class="nav-icon fa fa-handshake-o"></i>
                    <p>
                    الاستشارات
                    <i class="left fas fa-angle-left"></i>
                    </p>
                </a>
                <ul class="nav nav-treeview">
                    <li class="nav-item ">
                    <a href="#" class="nav-link mx-auto">
                        <i class="far  nav-icon"></i>
                        <p>الاستشارات الجارية</p>
                    </a>
                    </li>
                    
                    
                    <li class="nav-item">
                    <a href="#" class="nav-link mx-auto">
                        <i class="far  nav-icon"></i>
                        <p>الاستشارات المغلقة</p>
                    </a>
                    </li>
                    <li class="nav-item">
                    <a href="#" class="nav-link mx-auto">
                        <i class="far  nav-icon"></i>
                        <p>عرض جميع الاستشارات</p>
                    </a>
                    </li>
                </ul>
            </li>     
            <li class="nav-item mb-2">
                <a href="<?php echo e(route('users.edit')); ?>" class="nav-link mx-auto">
                    <i class="nav-icon fa fa-address-book"></i>
                <p>
                    تعديل الملف الشخصى
                    
                </p>
                </a>
                
            </li>
          
          
          
            <li class="nav-item mb-2">
                <a href="#" class="nav-link mx-auto">
                <i class="nav-icon fa fa-money"></i>
                <p>
                    
                    التبرع
                </p>
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="#" class="nav-link mx-auto">
                <i class="nav-icon fa fa-newspaper-o"></i>
                <p>
                    
                    البرامج و المؤتمرات
                </p>
                </a>
            </li>

          
          
         
          
          
          
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside><?php /**PATH C:\xampp\htdocs\Wataneya\resources\views/users/layout/inc/_sidebar_rtl.blade.php ENDPATH**/ ?>