<div>
    
    <div class="container red topBotomBordersOut">
        <a>HOME</a>
        <a>ARTICLES</a>
        <a>PORTFOLIO</a>
        <a>ABOUT</a>
        <a>CONTACT</a>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Wataneya\resources\views/livewire/navbar.blade.php ENDPATH**/ ?>