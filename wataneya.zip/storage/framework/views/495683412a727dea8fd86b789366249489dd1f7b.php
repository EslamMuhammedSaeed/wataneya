

<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0"><?php echo app('translator')->get('site.users'); ?></h1>
      </div><!-- /.col -->
      <div class="col-sm-6">
        <?php echo $__env->make('admin.layouts.inc._breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div><!-- /.col -->
    </div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->

<!-- Main content -->
<div class="content">
  <div class="container-fluid">
   
    <div class="card">
      <div class="card-header">
        
        <a href="#" class="btn btn-sm btn-success"><i class="fas fa-user-plus fa-sm mx-1"></i><?php echo app('translator')->get('site.add new'); ?></a>
      </div>
      <!-- /.card-header -->
      <div class="card-body">
        <?php if(session()->has('success')): ?> 
            <div class="alert alert-success mt-1 mx-4 mb-3 py-1">
                    <?php echo e(session('success')); ?>

              </div>
        <?php endif; ?>
        <table id="example1" class="table table-bordered table-striped">
          <thead>
          <tr>
            <th><?php echo app('translator')->get('site.id'); ?></th>
            <th><?php echo app('translator')->get('الاسم'); ?></th>
            <th><?php echo app('translator')->get('site.Last name'); ?></th>
            <th><?php echo app('translator')->get('site.email'); ?></th>
            <th><?php echo app('translator')->get('site.action'); ?></th>
            
          </tr>
          </thead>
          <tbody>
            
              <tr>
                <td><?php echo app('translator')->get('not found'); ?></td>
                <td><?php echo app('translator')->get('not found'); ?></td>
                <td><?php echo app('translator')->get('not found'); ?></td>
                <td><?php echo app('translator')->get('not found'); ?></td>
                <td><?php echo app('translator')->get('not found'); ?></td>
              </tr>
         
         
          </tbody>
          <tfoot>
          <tr>
            <th><?php echo app('translator')->get('site.id'); ?></th>
            <th><?php echo app('translator')->get('site.First name'); ?></th>
            <th><?php echo app('translator')->get('site.Last name'); ?></th>
            <th><?php echo app('translator')->get('site.email'); ?></th>
            <th><?php echo app('translator')->get('site.action'); ?></th>
          </tr>
          </tfoot>
        </table>
        
      </div>
      <!-- /.card-body -->
    </div>
    <!-- /.card -->
    
  </div>
  <!-- /.container-fluid -->
</div>
<!-- /.content -->
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Wataneya\resources\views/admin/newsletter/index.blade.php ENDPATH**/ ?>