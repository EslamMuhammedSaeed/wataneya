
<?php if(app()->getLocale() == 'ar'): ?>
    <ol class="breadcrumb float-sm-left">
        <li class="breadcrumb-item"><a href="#">Home</a></li>
        <li class="breadcrumb-item active">Dashboard v3</li>
    </ol>
<?php else: ?>
    <ol class="breadcrumb float-sm-right">
        <li class="breadcrumb-item"><a href="#">Home</a></li>
        <li class="breadcrumb-item active">Dashboard v3</li>
    </ol>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Wataneya\resources\views/admin/layouts/inc/_breadcrumb.blade.php ENDPATH**/ ?>