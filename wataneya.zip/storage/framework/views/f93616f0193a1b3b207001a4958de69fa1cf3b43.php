
    <!--nav-->

 <!--nav-->
 <!--start main section-->
 <?php $__env->startSection('css'); ?>
 <style>
input{
    font-family: 'dli' !important;

}
.avatar-upload {
    position: relative;
    max-width: 205px;
    margin: 10px auto;
   
   
}

.avatar-upload .avatar-edit {
    position: absolute;
    right: 12px;
    z-index: 1;
    top: 10px;
}
.avatar-upload .avatar-edit input {
    display: none;
}

.avatar-upload .avatar-edit input + label {
    display: inline-block;
    width: 34px;
    height: 34px;
    margin-bottom: 0;
    border-radius: 100%;
    background: #FFFFFF;
    border: 1px solid transparent;
    box-shadow: 0px 2px 4px 0px rgb(0 0 0 / 12%);
    cursor: pointer;
    font-weight: normal;
    transition: all 0.2s ease-in-out;
}

.avatar-upload .avatar-edit input + label:after {
    content: "\f040";
    font-family: 'FontAwesome';
    color: #757575;
    position: absolute;
    top: 6px;
    left: 0;
    right: 0;
    text-align: center;
    margin: auto;
}





        
        
        
       
.avatar-upload .avatar-preview {
  width: 192px;
  height: 192px;
  position: relative;
  border-radius: 100%;
  border: 6px solid #F8F8F8;
  box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.1);
}
.avatar-upload .avatar-preview > div {
  width: 100%;
  height: 100%;
  border-radius: 100%;
  background-size: cover;
  background-repeat: no-repeat;
  background-position: center;
}

.form-control.is-invalid, .was-validated .form-control:invalid {
    border: 0 !important;
    box-shadow: none;
}
.form-control:focus{
    border: 1px solid blue !important;
}
.form-control.is-valid, .was-validated .form-control:valid {
    border-color: blue;
    padding-right: calc(1.5em + 0.75rem);
    background-image: none !important;
    background-repeat: no-repeat;
    background-position: right calc(0.375em + 0.1875rem) center;
    background-size: calc(0.75em + 0.375rem) calc(0.75em + 0.375rem);
}

element.style {
}
.form-control.is-invalid, .was-validated .form-control:invalid {
    border: 0 !important;
    box-shadow: none;
}
.main-form .org-data .form-control {
    background-color: #ECECEC;
    border: 1px solid #D1D1D1;
    box-sizing: border-box;
    border-radius: 5px;
}

.form-custom{
    padding: 8px;
    display: block;
    width: 100%;
    background: #ECECEC;
    border: 1px solid #D1D1D1;
    box-sizing: border-box;
    border-radius: 5px;
    cursor: pointer;
}
.form-custom:focus{
    /* border: 3px solid rgba(0, 128, 0, 0.479) !important; */
}
input:focus,textarea:focus{
 outline: 2px solid rgba(0, 128, 0, 0.24);
}
input.form-custom.error{
    outline: 2px solid rgba(211, 1, 1, 0.664);
}

 </style>
     
 <?php $__env->stopSection(); ?>
 <?php $__env->startSection('content'); ?>
 
     
 
 <main class="pt-5 pb-5">
    
     <form method="post" action="<?php echo e(route('users.orphanage.store')); ?>" class="main-form was-validated px-5" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="user_id" id="user_id" value="<?php echo e(Auth::user()->id); ?>">
         <div class="form-container container bg-white p-3" style="border-radius:15px; ">
            <div class="avatar-upload">
                <div class="avatar-edit">
                    <input type='file' id="imageUpload" class="<?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="image" value="<?php echo e(old('image')); ?>" accept=".png, .jpg, .jpeg" />
                    <label for="imageUpload"></label>
                </div>
                <div class="avatar-preview">
                    <div id="imagePreview" style="background-image: url(<?php echo e(asset('img/camera.jpg')); ?>);">
                    </div>
                </div>
                <div class="text-center mt-2">
                    <label class="ml-3" for="">أﺿﻒ صورة</label>
                    <small class="ml-3">
                        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                             <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </small>
                </div>
                
            </div>

            
             <div class="row">
                 

                 <div class="col-12 ">

                   <div class="org-data">
                        <div class="row">
                            <div class="mb-3 col-md-4">
                            
                                <label  class="org-name">اﺳﻢ الجمعية<small class="text-danger mr-2">'مطلوب'</small></label>
                                <input type="text" class="form-custom <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="name" value="<?php echo e(old('name')); ?>">
                                <small>
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </small>
                            </div>
                            <div class="mb-3 col-md-4">
                            
                                <label  class="org-name">رقم الترخيص<small class="text-danger mr-2">'مطلوب'</small></label>
                                <input type="text" class="form-custom <?php $__errorArgs = ['license_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="license_number" value="<?php echo e(old('license_number')); ?>">
                                <small>
                                    <?php $__errorArgs = ['license_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </small>
                            </div>

                            <div class="mb-3 col-md-4">
                            
                                <label  class="org-name">رقم الموبايل<small class="text-danger mr-2">'مطلوب'</small></label>
                                <input type="text" class="form-custom <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="mobile" value="<?php echo e(old('mobile')); ?>">
                                <small>
                                    <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </small>
                            </div>
                            
                        </div>
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label  class="form-label">الدولة<small class="text-danger mr-2">'مطلوب'</small></label>
                                <input type="text" class="form-custom <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="country" value="<?php echo e(old('country')); ?>" >
                                <small>
                                    <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </small>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label  class="form-label">المحافظة<small class="text-danger mr-2">'مطلوب'</small></label>
                                <input type="text" class="form-custom <?php $__errorArgs = ['governorate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="governorate" value="<?php echo e(old('governorate')); ?>" >
                                <small>
                                    <?php $__errorArgs = ['governorate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </small>
                            </div>
                            
                        </div>
                        

                        

                        
                        
                        
                   </div>
                 </div>
             </div>
             
             
             
         </div>

         <div class="form-container container bg-white p-3 mt-4" style="border-radius:15px; ">
            <div class="py-3">
                <h3>
                    الاحتياجات التعليمية
                </h3>
            </div>

            
             <div class="row">
               

                 <div class="col-12 ">

                   <div class="org-data">
                        <div class="row">
                            <div class="mb-3 col-md-12">
                            
                                <label  class="org-name"> أعداد الاطفال في كل مرحلة دراسية والمراحل الجامعية ؟ 
                                    توضيح (رجاء كتابة السنوات الدراسية واعداد الأطفال بها  مثال  الصف الاول الابتدائى 10 اطفال  / الصف الثانى الابتدائى 5 اطفال )</label>
                                <input type="text" class="form-custom <?php $__errorArgs = ['children_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="children_no" value="<?php echo e(old('children_no')); ?>" >
                                <small>
                                    <?php $__errorArgs = ['children_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </small>
                            </div>
                            <div class="mb-3 col-md-4">
                            
                                <label  class="org-name">
                                    ما هي أنواع المدارس المقيد بها الأطفال؟  

                                </label>
                                <select class="form-control" name="schools_type" id="schools_type">
                                    <option value="" selected></option>                                       
                                    <option value="حكومية">حكومية</option>
                                    <option value="خاصة">خاصة</option>
                                    <option value="تجريبى">تجريبى</option>
                                    <option value="لغات">لغات</option>

                                </select>
                                
                                <small>
                                    <?php $__errorArgs = ['schools_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </small>
                            </div>

                            <div class="mb-3 col-md-12">
                            
                                <label  class="org-name">
                                    ما هى أنواع الجامعات المقيد بها الشباب؟
                                    (اسم الجامعة و الكلية) 
                                </label>
                                <input type="text" class="form-custom <?php $__errorArgs = ['Universities_names_with_colleges'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="Universities_names_with_colleges" value="<?php echo e(old('Universities_names_with_colleges')); ?>"  >
                                <small>
                                    <?php $__errorArgs = ['Universities_names_with_colleges'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </small>
                            </div>
                            
                        </div>
                      

                        
                   </div>
                 </div>
             </div>

         </div>

         <div class="form-container container bg-white p-3 mt-4" style="border-radius:15px; ">
            <div class="py-3">
                <h3>
                    الاحتياجات الصحية
                </h3>
            </div>

            
             <div class="row">
               

                 <div class="col-12 ">

                   <div class="org-data">
                        <div class="row">
                            <div class="mb-3 col-md-4">
                            
                                <label  class="org-name">
                                    هل توجد حقيبة إسعافات أولية؟    
                                </label>
                                <select class="form-control" name="first_aid_kit" id="first_aid_kit">
                                    <option value="" selected></option>                                       
                                    <option value="1">نعم</option>
                                    <option value="0">لا</option>
                                   

                                </select>
                                <small>
                                    <?php $__errorArgs = ['first_aid_kit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </small>
                            </div>

                           

                            <div class="mb-3 col-md-12">
                            
                                <label  class="org-name">
                                    هل تحتاج الى توفير اأدوية شهرية للأطفال لديها أمراض مزمنة؟
                                    فى حالة الإجابة بنعم برجاء تحديد نوع المرض واعداد الأطفال مثال ( مرض السكر  عدد 4 اطفال ) 
                                </label>
                                <input type="text" class="form-custom <?php $__errorArgs = ['medical_drugs_clarifications'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="medical_drugs_clarifications" value="<?php echo e(old('medical_drugs_clarifications')); ?>"  >

                                <small>
                                    <?php $__errorArgs = ['medical_drugs_clarifications'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </small>
                            </div>

                            <div class="mb-3 col-md-12">
                            
                                <label  class="org-name">
                                    هل يوجد حالات تحتاج إلى إجراء عمليات باهظة التكلفة ؟
                                    فى حالة الإجابة بنعم  برجاء كتابة  نوع العملية و العدد  مثال ( عملية قلب مفتوح  عدد 3 أطفال )
                                </label>
                                <input type="text" class="form-custom <?php $__errorArgs = ['medical_operations_clarifications'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="medical_operations_clarifications" value="<?php echo e(old('medical_operations_clarifications')); ?>"  >

                                <small>
                                    <?php $__errorArgs = ['medical_operations_clarifications'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </small>
                            </div>

                            <div class="mb-3 col-md-12">
                            
                                <label  class="org-name">
                                                                            هل يوجد حالات بحاجة إلى إجراء فحوصات وتحاليل دورية؟
                                        فى حالة الإجابة بنعم  برجاء كتابة  نوع الحالات والفحوصات والتحاليل المطلوبة  و العدد 
                                </label>
                                <input type="text" class="form-custom <?php $__errorArgs = ['medical_tests_clarifications'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="medical_tests_clarifications" value="<?php echo e(old('medical_tests_clarifications')); ?>"  >

                                <small>
                                    <?php $__errorArgs = ['medical_tests_clarifications'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </small>
                            </div>

                          
                            
                            
                        </div>
                      

                        
                   </div>
                 </div>
             </div>
             
             
             
         </div>


        <div class="form-container container bg-white p-3 mt-4" style="border-radius:15px; ">
            <div class="py-3">
                <h3>
                    احتياجات لدعم اجتماعي
                </h3>
            </div>

            
             <div class="row">
               

                 <div class="col-12 ">

                   <div class="org-data">
                        <div class="row">
                     
                            <div class="mb-3 col-md-12">
                            
                                <label  class="org-name">
                                                                        هل يوجد فتيات  بحاجة إلى تيسير الزواج و تكوين أسرة  ( جهاز العروسة ) ؟
                                    في حالة الإجابة بنعم  يرجى توضيح العدد و الاحتياجات المطلوبة 
                                </label>
                                <input type="text" class="form-custom <?php $__errorArgs = ['marriage_needs_clarifications'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="marriage_needs_clarifications" value="<?php echo e(old('marriage_needs_clarifications')); ?>"  >

                                <small>
                                    <?php $__errorArgs = ['marriage_needs_clarifications'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </small>
                            </div>

                            <div class="mb-3 col-md-12">
                            
                                <label  class="org-name">
                                    هل يوجد لدى الدار شباب أو شابات بحاجة الى إيجاد مورد رزق دائم لهم عن طريق توفير عمل يتناسب مع قدراته واستعداداته وتعليمه حتى يوفر لنفسه الطعام والشراب والحماية ؟
                                    في حالة الإجابة بنعم يرجى كتابة عدد الشباب  أو شابات و المؤهل الدارسى 
                                </label>
                                <input type="text" class="form-custom <?php $__errorArgs = ['job_needs_clarifications'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="job_needs_clarifications" value="<?php echo e(old('job_needs_clarifications')); ?>"  >

                                <small>
                                    <?php $__errorArgs = ['job_needs_clarifications'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </small>
                            </div>

                                              
                            
                            
                        </div>
                      

                        
                   </div>
                 </div>
             </div>
             
             
             
        </div>

        <div class="form-container container bg-white p-3 mt-4" style="border-radius:15px; ">
            <div class="py-3">
                <h3>
                    احتياجات تجهيزية للدار

                </h3>
            </div>

            
             <div class="row">
               

                 <div class="col-12 ">

                   <div class="org-data">
                        <div class="row">
                     
                            <div class="mb-3 col-md-12">
                            
                                <label  class="org-name">
                                    هل الدار تحتاج إلى ترميم أو اثاث؟
                                    في حالة الإجابة بنعم برجاء تحديد نوع الترميم او الأثاث المطلوب
                                </label>
                                <input type="text" class="form-custom <?php $__errorArgs = ['construction_needs_clarifications'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="construction_needs_clarifications" value="<?php echo e(old('construction_needs_clarifications')); ?>"  >

                                <small>
                                    <?php $__errorArgs = ['construction_needs_clarifications'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </small>
                            </div>

                            <div class="mb-3 col-md-12">
                            
                                <label  class="org-name">
                                    هل يوجد فرش للأرضيات من خامات صحية و جيدة (سجاد أو كليم ) ؟
                                    في حالة الإجابة  ب ( لا)  يرجى كتابة العدد المطلوب 
                                </label>
                                <input type="text" class="form-custom <?php $__errorArgs = ['carpets'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="carpets" value="<?php echo e(old('carpets')); ?>"  >

                                <small>
                                    <?php $__errorArgs = ['carpets'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </small>
                            </div>
                            <div class="mb-3 col-md-12">
                            
                                <label  class="org-name">
                                    هل لدى الدار مفروشات تكفي عدد الأطفال و الشباب الموجودين في الدار  مثل ( ستائر - ملاءات - كوفرتات  - الفوط ) ؟
                                    في حالة الإجابة  ب (لا)  يرجى كتابة  نوع الفرش المطلوب  والعدد 
                                </label>
                                <input type="text" class="form-custom <?php $__errorArgs = ['curtains'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="curtains" value="<?php echo e(old('curtains')); ?>"  >

                                <small>
                                    <?php $__errorArgs = ['curtains'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </small>
                            </div>

                            <div class="mb-3 col-md-12">
                            
                                <label  class="org-name">
                                    هل يوجد ألعاب للأطفال ملائمة لأعمارهم؟
                                    في حالة الإجابة ب (لا)  يرجي ذكر العدد و عمر الأطفال 
                                </label>
                                <input type="text" class="form-custom <?php $__errorArgs = ['toys'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="toys" value="<?php echo e(old('toys')); ?>"  >

                                <small>
                                    <?php $__errorArgs = ['toys'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </small>
                            </div>

                            <div class="mb-3 col-md-12">
                            
                                <label  class="org-name">
                                    هل يوجد مكتبة بالدار ؟
                                    في حالة الإجابة ب (لا)  يرجي ذكر العدد و عمر الأطفال 
                                </label>
                                <input type="text" class="form-custom <?php $__errorArgs = ['library'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="library" value="<?php echo e(old('library')); ?>"  >

                                <small>
                                    <?php $__errorArgs = ['library'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </small>
                            </div>

                            <div class="mb-3 col-md-12">
                            
                                <label  class="org-name">
                                    هل يوجد أواني للطبخ صحية  نوعها  ستانلس ستيل ؟
                                    في حالة الإجابة بنعم  يرجى ذكر  عدد الأواني 
                                </label>
                                <input type="text" class="form-custom <?php $__errorArgs = ['utensils'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="utensils" value="<?php echo e(old('utensils')); ?>"  >

                                <small>
                                    <?php $__errorArgs = ['utensils'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </small>
                            </div>

                            <div class="mb-3 col-md-12">
                            
                                <label  class="org-name">
                                    هل الدرا في حاجة إلى أجهزة كمبيوتر ؟
                                    في حالة الإجابة بنعم يرجى ذكر عدد الأجهزة المطلوبة 
                                </label>
                                <input type="text" class="form-custom <?php $__errorArgs = ['computers'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="computers" value="<?php echo e(old('computers')); ?>"  >

                                <small>
                                    <?php $__errorArgs = ['computers'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </small>
                            </div>

                            <div class="mb-3 col-md-12">
                            
                                <label  class="org-name">
                                    هل الدار في حاجة إلى كسوة للشتاء - كسوة للصيف ( ملابس شتوية - صيفية ) ؟
                                    في حالة الإجابة بنعم يرجى توضيح الأعمار والملابس المطلوبة والمقاسات 
                                </label>
                                <input type="text" class="form-custom <?php $__errorArgs = ['clothes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="clothes" value="<?php echo e(old('clothes')); ?>"  >

                                <small>
                                    <?php $__errorArgs = ['clothes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </small>
                            </div>

                            <div class="mb-3 col-md-12">
                            
                                <label  class="org-name">
                                    هل يوجد للدار أي إحتياجات أخرى لم يتم ذكرها ؟
                                </label>
                                <input type="text" class="form-custom <?php $__errorArgs = ['other_needs'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="other_needs" value="<?php echo e(old('other_needs')); ?>"  >

                                <small>
                                    <?php $__errorArgs = ['other_needs'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </small>
                            </div>
                                              
                            
                            
                        </div>
                      

                        
                   </div>
                 </div>
             </div>
             
             
             <div class="button-holder mb-5 mt-4">
                <input type="submit" class="btn btn-primary btn-block" value="حفظ">
             </div>
        </div>
     </form>
 </main>
 <!--end main section-->





    <!--start js files-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
   
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    // var x= $(".error:first");
    // console.log(x);
    // x.scrollIntoView({
    //     behavior: 'smooth'
    // });
    if($('.error').length > 0){
        $('html, body').animate({
            scrollTop: ($('.error').first().offset().top)
        },500);
        var img= $("#imageUpload").val();
    }
    console.log(img);
    
    function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#imagePreview').css('background-image', 'url('+e.target.result +')');
                    $('#imagePreview').hide();
                    $('#imagePreview').fadeIn(650);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
        $("#imageUpload").change(function() {
            readURL(this);
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Wataneya\resources\views/users/orphanage_form.blade.php ENDPATH**/ ?>